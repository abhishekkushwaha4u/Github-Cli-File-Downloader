# Github File Downloader

This is a simple cli package to download individual files from github, for public repositories